import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeServiceService } from '../employee-service.service';

@Component({
  selector: 'app-employee-display',
  templateUrl: './employee-display.component.html',
  styleUrls: ['./employee-display.component.css']
})
export class EmployeeDisplayComponent implements OnInit {

  emp: Employee[]=[];
  constructor(private service:EmployeeServiceService) { }

  ngOnInit(){
    let resp=this.service.displayAll();
    this.emp=resp;
  }

}
