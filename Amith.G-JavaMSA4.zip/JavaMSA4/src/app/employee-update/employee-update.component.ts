import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeServiceService } from '../employee-service.service';

@Component({
  selector: 'app-employee-update',
  templateUrl: './employee-update.component.html',
  styleUrls: ['./employee-update.component.css']
})
export class EmployeeUpdateComponent implements OnInit {

  employee: Employee=new Employee();
  message: any;

  constructor(private service:EmployeeServiceService) { }

  ngOnInit(){
  }

  public registerNow(){
    let resp= this.service.updateEmployee(this.employee);
    this.message=resp;
  }

}
