export class User {
    private username:string="";
    private password:string="";

    constructor(username:string="",password:string=""){
        this.username=username;
        this.password=password;
    }

    public get uname()
    {
        return this.username;
    }

    public set uname(username)
    {
        this.username=username;
    }

    public get pass()
    {
        return this.password;
    }

    public set pass(password)
    {
        this.password=this.password;
    }

}
