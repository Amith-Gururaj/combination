import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeDisplayComponent } from './employee-display/employee-display.component';
import { EmployeeRegisterComponent } from './employee-register/employee-register.component';
import { EmployeeUpdateComponent } from './employee-update/employee-update.component';
import { HomePageComponent } from './home-page/home-page.component';
import { UserLoginComponent } from './user-login/user-login.component';

const routes: Routes = [
  {path:"User-Login",component:UserLoginComponent},
  {path:"Home-Page",component:HomePageComponent},
  {path:"Employee-Register",component:EmployeeRegisterComponent},
  {path:"Employee-display",component:EmployeeDisplayComponent},
  {path:"Employee-update",component:EmployeeUpdateComponent},
  {path:"",redirectTo:"User-Login",pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
