import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {
  updateItem: any;

  constructor() { }
  employees: Employee[]=[];

  public addEmployee(emp:Employee)
  {
    this.employees.push(emp);
    return "Employee Added Successfully";
  }


  public displayAll()
  {
    return this.employees;
  }

  public updateEmployee(emp:Employee)
  {
    this.updateItem = this.employees.find(this.findIndexToUpdate,emp.eid);
    let index = this.employees.indexOf(this.updateItem);
    this.employees[index] = emp;
    return "Employee Details Updated Successfully";
  }

  findIndexToUpdate(emp:any) { 
        return emp.eid === this;
  }
}
