import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeServiceService } from '../employee-service.service';

@Component({
  selector: 'app-employee-register',
  templateUrl: './employee-register.component.html',
  styleUrls: ['./employee-register.component.css']
})
export class EmployeeRegisterComponent implements OnInit {

  employee: Employee=new Employee();
  message: any;

  constructor(private service:EmployeeServiceService) { }

  ngOnInit(){
  }

  public registerNow(){
    let resp= this.service.addEmployee(this.employee);
    this.message=resp;
  }

}


