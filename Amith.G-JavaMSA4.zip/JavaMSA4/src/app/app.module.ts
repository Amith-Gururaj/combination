import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { EmployeeRegisterComponent } from './employee-register/employee-register.component';
import { EmployeeDisplayComponent } from './employee-display/employee-display.component';
import { EmployeeUpdateComponent } from './employee-update/employee-update.component';
import { FormsModule } from '@angular/forms';
import { EmployeeServiceService } from './employee-service.service';
import { HomePageComponent } from './home-page/home-page.component';

@NgModule({
  declarations: [
    AppComponent,
    UserLoginComponent,
    EmployeeRegisterComponent,
    EmployeeDisplayComponent,
    EmployeeUpdateComponent,
    HomePageComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [EmployeeServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
