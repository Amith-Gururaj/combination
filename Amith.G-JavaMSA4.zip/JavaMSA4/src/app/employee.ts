export class Employee {
    private id:number=0;
    private name:string="";
    private salary:number=0;
    private gender:string="";

    constructor(id:number=0,name:string="",salary:number=0,gender:string="")
    {
        this.id=id;
        this.name=name;
        this.salary=salary;
        this.gender=gender;
    }

    public get eid()
    {
        return this.id;
    }

    public set eid(id)
    {
        this.id=id;
    }

    public get ename()
    {
        return this.name;
    }

    public set ename(name)
    {
        this.name=name;
    }

    public get esalary()
    {
        return this.salary;
    }

    public set esalary(salary)
    {
        this.salary=salary;
    }

    public get egender()
    {
        return this.gender;
    }

    public set egender(gender)
    {
        this.gender=gender;
    }
}
